# quipclient/quip/__init__.py

from quipclient.quip import QuipClient, QuipError
